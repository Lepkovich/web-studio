#Steps to run the project:
1. Run `npm i`
2. Run `npm install -g migrate-mongo`
3. Run `migrate-mongo up`
4. To start the project run `npm start`