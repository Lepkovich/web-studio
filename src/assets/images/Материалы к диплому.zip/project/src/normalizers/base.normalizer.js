class BaseNormalizer {
    normalize() {}
}

module.exports = BaseNormalizer;